-keepclasseswithmembernames class * {
    native <methods>;
}
